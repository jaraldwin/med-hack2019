package com.example.comptermsquiz;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterViewFlipper;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CompActivity  extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private AdapterViewFlipper adapterViewFlipper;
    private Button btnPrevious, btnNext;

    private long backPressedTime;
    Dialog myDialog;
    String uriString;

    private static final String[] TEXT = {" ",
            " ", " ", " ", " ", ""};
    private static final int[] IMAGES = {R.drawable.ferlin, R.drawable.doh1, R.drawable.doh3,
            R.drawable.doh4, R.drawable.doh5, R.drawable.doh6};


    private int mPosition = -1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comp);
        myDialog = new Dialog(this);
        adapterViewFlipper = (AdapterViewFlipper) findViewById(R.id.idAdapterViewFlipper);
        FlipperAdapter adapter = new FlipperAdapter(this, TEXT, IMAGES);
        adapterViewFlipper.setAdapter(adapter);
        adapterViewFlipper.setAutoStart(true);


    Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(this);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar
                , R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        if (savedInstanceState == null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    new MenuFragment()).commit();

            navigationView.setCheckedItem(R.id.nav_menu);}

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case  R.id.nav_menu:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new MenuFragment()).commit();
                break;
            case  R.id.nav_categories:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new CategoriesFragment()).commit();

                break;
            case  R.id.nav_his:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new HistoryFragment()).commit();
                break;
            case  R.id.nav_parts:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new PartsFragment()).commit();
                break;
          


            case  R.id.nav_les4:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson4()).commit();
                break;

            case  R.id.nav_les5:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson5()).commit();
                break;

            case  R.id.nav_les6:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson6()).commit();
                break;

            case  R.id.nav_les7:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson7()).commit();
                break;
            case  R.id.nav_les8:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson8()).commit();
                break;

            case  R.id.nav_les9:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson9()).commit();
                break;

            case  R.id.nav_les10:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentLesson10()).commit();
                break;

        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private void finishDrawer(){

        Intent resultIntent = new Intent();
        setResult(RESULT_OK, resultIntent);

        finish();
    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()){

            finishDrawer();

        }else{
            Toast.makeText(this, "Are you sure do you want to exit?", Toast.LENGTH_SHORT).show();
        }

        backPressedTime = System.currentTimeMillis();

    }

    public void ShowPopup(View v) {
        TextView txtclose;
        Button btn;

        myDialog.setContentView(R.layout.custompopup);
        txtclose =(TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");
        btn = (Button) myDialog.findViewById(R.id.btnfollow);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }
    public void btnClick(View w){
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        uriString = "https://www.facebook.com";
        sharingIntent.putExtra(Intent.EXTRA_TEXT,uriString);
        sharingIntent.setPackage("com.facebook.katana");
        startActivity(sharingIntent);
    }


    public void ShowPopupdev(View v) {
        TextView txtclose;
        Button btnFollow;
        myDialog.setContentView(R.layout.compdev);
        txtclose =(TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");
        btnFollow = (Button) myDialog.findViewById(R.id.btnfollow);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

    }


    public void ShowPopupsetting(View v) {
        TextView txtclose;
        Button btnFollow;

        myDialog.setContentView(R.layout.compsetting);
        txtclose =(TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");
        btnFollow = (Button) myDialog.findViewById(R.id.btnfollow);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }

    public void btnClick1(View w){
        String url = "http://maps.google.co.uk/maps?q=Pharmacy&hl=en";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.setClassName("com.google.android.apps.maps","com.google.android.maps.MapsActivity");
        startActivity(intent);
    }
    public void btnClick2(View w){
        String url = "https://www.healthmap.org/en/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    public void btnClick3(View w){
        String url = "http://maps.google.co.uk/maps?q=Hospital&hl=en";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.setClassName("com.google.android.apps.maps","com.google.android.maps.MapsActivity");
        startActivity(intent);
    }

    public void ShowPopuptutorial(View v) {
        TextView txtclose;
        Button btnFollow;

        myDialog.setContentView(R.layout.comptutorial);
        txtclose =(TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");
        btnFollow = (Button) myDialog.findViewById(R.id.btnfollow);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
}

    class FlipperAdapter extends BaseAdapter {
        Context ctx;
        int[] images;
        String[] text;
        LayoutInflater inflater;

        public FlipperAdapter (Context context, String[] myText, int[] myImages){
            this.ctx = context;
            this.images = myImages;
            this.text = myText;
            inflater = LayoutInflater.from(context);
        }
        @Override
        public int getCount(){
            return text.length;
        }

        @Override
        public Object getItem (int i){
            return null;
        }

        @Override
        public long getItemId (int i){
            return 0;
        }

        @Override
        public View getView (int i, View view, ViewGroup viewGroup){
            view = inflater.inflate(R.layout.flipper_item, null);
            TextView txtName = (TextView) view.findViewById(R.id.idTextView);
            ImageView txtImage = (ImageView) view.findViewById(R.id.idImageView);
            txtName.setText(text[i]);
            txtImage.setImageResource(images[i]);
            return view;
        }


    }


